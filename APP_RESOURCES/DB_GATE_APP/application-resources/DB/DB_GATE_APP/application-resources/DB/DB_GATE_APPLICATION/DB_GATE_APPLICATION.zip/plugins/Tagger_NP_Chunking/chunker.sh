#!/bin/sh

java -cp Chunker.jar mark.chunking.Chunker rules pos_tag_dict
